$(document).ready(function() {
  $('#menuBar').on('click', function(){
    $('#mobile-nav').slideToggle(350);
  });
});