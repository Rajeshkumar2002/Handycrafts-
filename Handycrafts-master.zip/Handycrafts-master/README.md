# Basantacrafts
A static website made with HTML, CSS and Javascript. Basantacrafts is a handicraft store which sells products that are handmade and made in Nepal.
